<?php
    defined('BASEPATH') OR exit('No direct script access allowed');

    $this->load->helper('url'); //For base URL
?>

		</main>

		<footer>
			< footer >
		</footer>
	</body>
</html>
